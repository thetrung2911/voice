//
//  Sever.swift
//  voice
//
//  Created by Trung Le on 27/05/2021.
//

import Alamofire
// MARK:- func reques
extension DataService {
    /// API post Register
    func requestPostApiServer(urlRequest: String, param: [String:Any],
                              header: HTTPHeaders = [:],
                              succcess: @escaping (BaseResponseApi<Friend>) -> Void,
                              failure:@escaping (String) -> Void) {
        self.requestPostData(urlInput: urlRequest,
                             parameter: param,
                             header: header,
                             isRequestBody: true,
                             success: { (results) in
            succcess(results)
        }) { (error) -> (Void) in
            failure(error)
        }
    }
}
