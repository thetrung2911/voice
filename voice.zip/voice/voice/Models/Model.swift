//
//  Model.swift
//  voice
//
//  Created by Trung Le on 27/05/2021.
//

import Foundation

struct Friend: Codable {
    var id: Int?
    var avatar_url: String?
    var nickname: String?
    var age: Int?
    var gender: Int?
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case avatar_url = "avatar_url"
        case nickname = "nickname"
        case age = "age"
        case gender = "gender"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try? container.decode(Int.self, forKey: .id)
        avatar_url = try? container.decode(String.self, forKey: .avatar_url)
        nickname = try? container.decode(String.self, forKey: .nickname)
        age = try? container.decode(Int.self, forKey: .age)
        gender = try? container.decode(Int.self, forKey: .gender)
    }
}

struct Result_error: Codable {
    var username: [String]?
    var email: [String]?
    var system_error: [String]?
    var password: [String]?
    var error: String?
    var contact_div: [String]?
    var message: String?
    
    enum CodingKeys: String, CodingKey {
        case username = "username"
        case email = "login_id"
        case system_error = "system_error"
        case password = "password"
        case error = "error"
        case contact_div = "contact_div"
        case message = "message"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        username = try? container.decode([String].self, forKey: .username)
        email = try? container.decode([String].self, forKey: .email)
        system_error = try? container.decode([String].self, forKey: .system_error)
        password = try? container.decode([String].self, forKey: .password)
        error = try? container.decode(String.self, forKey: .error)
        contact_div = try? container.decode([String].self, forKey: .contact_div)
        message = try? container.decode(String.self, forKey: .message)
    }
}
