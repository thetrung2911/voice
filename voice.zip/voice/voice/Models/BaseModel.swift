//
//  BaseModel.swift
//  voice
//
//  Created by Trung Le on 27/05/2021.
//

import Foundation
import UIKit

class BaseResponseApi<T: Codable>: Codable {
    var result_code: Int
    var result_detail : T?
    var result_error: Result_error?
    
    
    enum CodingKeys: String, CodingKey {
        case result_code
        case result_detail
        case result_error
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        result_code = try container.decode(Int.self, forKey: .result_code)
        result_detail = try? container.decode(T.self, forKey: .result_detail)
        result_error = try? container.decode(Result_error.self, forKey: .result_error)
    }
}
