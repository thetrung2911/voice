//
//  AudioRecorderFrame.swift
//  test
//
//  Created by Duong Hong Hung on 26/05/2021.
//

import Foundation
import AVFoundation

class AudioRecorderFrame {
    
    private var audioEngine: AVAudioEngine? = nil
    
    public func start() {
        audioEngine = AVAudioEngine()
        guard let input = audioEngine?.inputNode else {
            return
        }
        
        let bus = 0
        let channelMono = 1;
        let threshold = 0.1;
        let inputFormat = input.inputFormat(forBus: bus)
        let inputBufferSize = UInt32(inputFormat.sampleRate * threshold)
        guard let codec = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 8000, channels: AVAudioChannelCount(channelMono), interleaved: false),
              let converter = AVAudioConverter(from: inputFormat, to: codec)
        else {
            return
        }
        var lastEpoch: Int64 = 0
        input.installTap(onBus: bus, bufferSize: inputBufferSize, format: inputFormat) { inputBuffer, inputTime in
            let capacity = AVAudioFrameCount(codec.sampleRate) * inputBuffer.frameLength / AVAudioFrameCount(inputBuffer.format.sampleRate)
            let outputBuffer = AVAudioPCMBuffer(pcmFormat: codec, frameCapacity: capacity)!
            let inputBlockCallback: AVAudioConverterInputBlock = { packetCount, status in
                status.pointee = .haveData
                return inputBuffer
            }
            var error: NSError?
            let status = converter.convert(to: outputBuffer, error: &error, withInputFrom: inputBlockCallback)
            if (status != .error) {
                let sampleRate = outputBuffer.format.sampleRate
                let frameLength = Int(outputBuffer.frameLength)
                let bytesPerFrame = outputBuffer.format.streamDescription.pointee.mBytesPerFrame
                let epoch: Int64 = 0
                let shiftMsec = epoch - lastEpoch
                
//                let pointer = UnsafeBufferPointer(start: outputBuffer.int16ChannelData, count: channelMono)
//                let data = NSData(bytes: pointer[0], length: frameLength * Int(bytesPerFrame))
                print("sampleRate = \(sampleRate), frameLength = \(frameLength), bytesPerFrame = \(bytesPerFrame), shiftMsec = \(shiftMsec)")
                lastEpoch = epoch
            }
        }
        lastEpoch = 0
        audioEngine?.prepare()
        try! audioEngine?.start()
    }
    
    public func interrupt() {
        print("stop")
        let input = audioEngine?.inputNode
        input?.removeTap(onBus: 0)
        audioEngine?.stop()
    }
}
