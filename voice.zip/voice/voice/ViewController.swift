//
//  ViewController.swift
//  voice
//
//  Created by Trung Le on 27/05/2021.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    private var audioEngine: AVAudioEngine!
    private var mic: AVAudioInputNode!
    private var micTapped = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        configureAudioSession()
        audioEngine = AVAudioEngine()
        mic = audioEngine.inputNode
    }
    
    @IBAction func onVoiceAction(_ sender: Any) {
        if micTapped {
            mic.removeTap(onBus: 0)
            micTapped = false
            return
        }
        
        let micFormat = mic.inputFormat(forBus: 0)
        mic.installTap(onBus: 0, bufferSize: 2048, format: micFormat) { (buffer, when) in
            let sampleData = UnsafeBufferPointer(start: buffer.floatChannelData![0], count: Int(buffer.frameLength))
            print("sampleData: \(sampleData)")
        }
        micTapped = true
        startEngine()
    }
    
    // MARK:- Internal Methods
    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playAndRecord, options: [.mixWithOthers, .defaultToSpeaker])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { }
    }
    
    private func readableAudioFileFrom(url: URL) -> AVAudioFile {
        var audioFile: AVAudioFile!
        do {
            try audioFile = AVAudioFile(forReading: url)
        } catch { }
        return audioFile
    }
    
    private func startEngine() {
        guard !audioEngine.isRunning else {
            return
        }
        
        do {
            try audioEngine.start()
        } catch { }
    }
    
    private func stopAudioPlayback() {
        audioEngine.stop()
        audioEngine.reset()
    }
}

